/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.compensar.codigo;

import java.time.LocalDate;

import java.time.LocalDate;

// Clase que representa un alimento dentro del sistema de donaciones.

public class Alimento implements Comparable<Alimento> {

 
    private String nombre;               
    private String tipo;                 
    private int cantidad;                
    private String donante;              
    private LocalDate fechaRecepcion;    
    private LocalDate fechaVencimiento;  

   
    
    public Alimento(String nombre, String tipo, int cantidad, String donante,
                    String fechaRecepcion, String fechaVencimiento) {

        this.nombre = nombre;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.donante = donante;
        this.fechaRecepcion = LocalDate.parse(fechaRecepcion);
        this.fechaVencimiento = LocalDate.parse(fechaVencimiento);
    }


    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public String getDonante() {
        return donante;
    }

    public LocalDate getFechaRecepcion() {
        return fechaRecepcion;
    }

    public LocalDate getFechaVencimiento() {
        return fechaVencimiento;
    }

  
    @Override
    public int compareTo(Alimento otro) {
        return this.fechaVencimiento.compareTo(otro.fechaVencimiento);
    }

    
    @Override
    public String toString() {
        return "Donante: " + donante +
               "\nTipo: " + tipo +
               "\nAlimento: " + nombre +
               "\nCantidad: " + cantidad +
               "\nRecepción: " + fechaRecepcion +
               "\nVence: " + fechaVencimiento;
    }
}
