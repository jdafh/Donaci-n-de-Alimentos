package edu.compensar.codigo;

import java.util.PriorityQueue;
import java.util.HashMap;



/**
 * Clase que distribuye los alimentos según su prioridad y cantidad.
 * Recibe la información del Administrador (PriorityQueue ordenada).
 */
public class Distribuidor {

    
    private String[] departamentos = {
        "La Guajira", "Sucre", "Córdoba", "Chocó", "Vaupés",
        "Guainía", "San Andrés y Providencia", "Nariño", "Atlántico",
        "Bolívar", "Vichada", "Casanare", "Cesar", "Magdalena"
    };

    // Distribuye los alimentos por cantidad, equitativamente.
    
    public HashMap<String, Integer> distribuir(PriorityQueue<Alimento> cola) {

        HashMap<String, Integer> distribucion = new HashMap<>();

      
        for (String dep : departamentos) {
            distribucion.put(dep, 0);
        }

        
        while (!cola.isEmpty()) {
            Alimento alimento = cola.poll(); 

           int cantidad = alimento.getCantidad();

            int numDepartamentos = departamentos.length;

            
            int porDepartamento = cantidad / numDepartamentos;
            int sobrante = cantidad % numDepartamentos;

           
            for (int i = 0; i < departamentos.length; i++) {
                String dep = departamentos[i];

                int reparto = porDepartamento;

                
                if (sobrante > 0) {
                    reparto++;
                    sobrante--;
                }

                distribucion.put(dep, distribucion.get(dep) + reparto);
            }
        }

        return distribucion;
    }
}