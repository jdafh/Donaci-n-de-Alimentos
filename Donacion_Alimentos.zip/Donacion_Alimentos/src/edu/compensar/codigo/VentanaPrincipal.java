/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package edu.compensar.codigo;


import java.awt.*;
import java.util.PriorityQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class VentanaPrincipal extends JFrame {

    private Administrador admin = new Administrador();
    private GrafoDepartametos grafo = new GrafoDepartametos();
    private Distribuidor distribuidor = new Distribuidor();
    
    // Componentes principales
    private JPanel panelPrincipal;
    private JPanel panelContenido;
    private CardLayout cardLayout;
    
    // Paneles de vista
    private JPanel panelDecontrol;
    private JPanel panelRegistro;
    private JPanel panelInventario;
    private JPanel panelDistribucion;
    
    // Colores del tema
    private final Color COLOR_PRIMARIO = new Color(56, 142, 60);
    private final Color COLOR_SECUNDARIO = new Color(46, 125, 50);
    private final Color COLOR_FONDO = new Color(245, 245, 245);
    private final Color COLOR_CARD = Color.WHITE;
    private final Color COLOR_TEXTO = new Color(33, 33, 33);
    private final Color COLOR_TEXTO_SECUNDARIO = new Color(117, 117, 117);
    private final Color COLOR_ALERTA = new Color(244, 67, 54);
    private final Color COLOR_ADVERTENCIA = new Color(255, 152, 0);
    private final Color COLOR_EXITO = new Color(76, 175, 80);

    public VentanaPrincipal() {
        configurarVentana();
        inicializarComponentes();
        cargarDatosPrueba(); // Para testing
    }

    private void configurarVentana() {
        setTitle("Sistema de Donación de Alimentos - ODS Hambre Cero");
        setSize(1200, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(COLOR_FONDO);
    }

    private void inicializarComponentes() {
        // Panel principal con navegación lateral
        panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(COLOR_FONDO);
        
        // Crear barra lateral
        JPanel panelLateral = crearPanelLateral();
        panelPrincipal.add(panelLateral, BorderLayout.WEST);
        
        // Panel de contenido con CardLayout
        cardLayout = new CardLayout();
        panelContenido = new JPanel(cardLayout);
        panelContenido.setBackground(COLOR_FONDO);
        
        // Crear todas las vistas
        panelDecontrol =  CrearPanelDecontrol ();
        panelRegistro = crearPanelRegistro();
        panelInventario = crearPanelInventario();
        panelDistribucion = crearPanelDistribucion();
        
        // Agregar vistas al CardLayout
        panelContenido.add(panelDecontrol, " Panel de control");
        panelContenido.add(panelRegistro, "registro");
        panelContenido.add(panelInventario, "inventario");
        panelContenido.add(panelDistribucion, "distribucion");
        
        panelPrincipal.add(panelContenido, BorderLayout.CENTER);
        add(panelPrincipal);
    }

    private JPanel crearPanelLateral() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(COLOR_PRIMARIO);
        panel.setPreferredSize(new Dimension(250, 0));
        panel.setBorder(new EmptyBorder(20, 0, 20, 0));
        
        // Logo/Título
        JLabel lblTitulo = new JLabel("🍗 ODS Hambre Cero");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblTitulo.setBorder(new EmptyBorder(0, 0, 30, 0));
        panel.add(lblTitulo);
        
        // Botones de navegación
        panel.add(crearBotonNavegacion("📊 Panel de control", " Panel de control"));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(crearBotonNavegacion("➕ Registrar Alimento", "registro"));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(crearBotonNavegacion("📦 Inventario", "inventario"));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(crearBotonNavegacion("🚚 Distribución", "distribucion"));
        
        panel.add(Box.createVerticalGlue());
        
        // Info del sistema
        JLabel lblVersion = new JLabel("v1.0.0");
        lblVersion.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblVersion.setForeground(new Color(255, 255, 255, 180));
        lblVersion.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(lblVersion);
        
        return panel;
    }

    private JButton crearBotonNavegacion(String texto, String vista) {
        JButton btn = new JButton(texto);
        btn.setMaximumSize(new Dimension(230, 50));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(46, 125, 50));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(COLOR_SECUNDARIO);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(46, 125, 50));
            }
        });
        
        btn.addActionListener(e -> {
            cardLayout.show(panelContenido, vista);
            if (vista.equals("dashboard") || vista.equals("inventario")) {
                actualizarVistas();
            }
        });
        
        return btn;
    }

    private JPanel CrearPanelDecontrol() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));
        
        // Título
        JLabel titulo = new JLabel("Panel de control General");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setForeground(COLOR_TEXTO);
        panel.add(titulo, BorderLayout.NORTH);
        
        // Panel de estadísticas
        JPanel panelStats = new JPanel(new GridLayout(1, 4, 20, 0));
        panelStats.setBackground(COLOR_FONDO);
        
        panelStats.add(crearCardEstadistica("Total Alimentos", "0", "📦", COLOR_PRIMARIO));
        panelStats.add(crearCardEstadistica("Próximos a Vencer", "0", "⚠️", COLOR_ADVERTENCIA));
        panelStats.add(crearCardEstadistica("Total Unidades", "0", "📊", new Color(33, 150, 243)));
        panelStats.add(crearCardEstadistica("Distribuidos Hoy", "0", "✓", COLOR_EXITO));
        
        panel.add(panelStats, BorderLayout.CENTER);
        
        // Panel inferior con información adicional
        JPanel panelInferior = new JPanel(new GridLayout(1, 2, 20, 0));
        panelInferior.setBackground(COLOR_FONDO);
        
        // Próximo a vencer
        JPanel cardProximo = crearCardConTitulo("🔔 Próximo a Vencer");
        JLabel lblProximo = new JLabel("<html><center>Sin alimentos registrados</center></html>");
        lblProximo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblProximo.setHorizontalAlignment(SwingConstants.CENTER);
        cardProximo.add(lblProximo, BorderLayout.CENTER);
        panelInferior.add(cardProximo);
        
        // Distribución por tipo
        JPanel cardTipos = crearCardConTitulo("📈 Distribución por Tipo");
        JLabel lblTipos = new JLabel("<html><center>Sin datos disponibles</center></html>");
        lblTipos.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblTipos.setHorizontalAlignment(SwingConstants.CENTER);
        cardTipos.add(lblTipos, BorderLayout.CENTER);
        panelInferior.add(cardTipos);
        
        panel.add(panelInferior, BorderLayout.SOUTH);
        
        return panel;
    }

    private JPanel crearCardEstadistica(String titulo, String valor, String icono, Color color) {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setBackground(COLOR_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
            new EmptyBorder(20, 20, 20, 20)
        ));
        
        JLabel lblIcono = new JLabel(icono);
        lblIcono.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
        card.add(lblIcono, BorderLayout.WEST);
        
        JPanel panelTexto = new JPanel();
        panelTexto.setLayout(new BoxLayout(panelTexto, BoxLayout.Y_AXIS));
        panelTexto.setBackground(COLOR_CARD);
        
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblTitulo.setForeground(COLOR_TEXTO_SECUNDARIO);
        
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblValor.setForeground(color);
        
        panelTexto.add(lblTitulo);
        panelTexto.add(lblValor);
        
        card.add(panelTexto, BorderLayout.CENTER);
        
        return card;
    }

    private JPanel crearCardConTitulo(String titulo) {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setBackground(COLOR_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
            new EmptyBorder(20, 20, 20, 20)
        ));
        
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitulo.setForeground(COLOR_TEXTO);
        card.add(lblTitulo, BorderLayout.NORTH);
        
        return card;
    }

    private JPanel crearPanelRegistro() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));
        
        JLabel titulo = new JLabel("Registrar Nuevo Alimento");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setForeground(COLOR_TEXTO);
        panel.add(titulo, BorderLayout.NORTH);
        
        // Formulario
        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBackground(COLOR_CARD);
        formulario.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
            new EmptyBorder(30, 40, 30, 40)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Campos del formulario
        JTextField txtDonante = agregarCampoFormulario(formulario, "Nombre del Donante:", 0, gbc);
        
        String[] tipos = {"Frutas", "Granos", "Vegetales", "Carnes", "Enlatados", "Harinas"};
        JComboBox<String> cmbTipo = new JComboBox<>(tipos);
        cmbTipo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        agregarCampoFormulario(formulario, "Tipo de Alimento:", cmbTipo, 1, gbc);
        
        JTextField txtNombre = agregarCampoFormulario(formulario, "Nombre del Alimento:", 2, gbc);
        JTextField txtCantidad = agregarCampoFormulario(formulario, "Cantidad:", 3, gbc);
        JTextField txtFechaRecepcion = agregarCampoFormulario(formulario, "Fecha Recepción (YYYY-MM-DD):", 4, gbc);
        JTextField txtFechaVencimiento = agregarCampoFormulario(formulario, "Fecha Vencimiento (YYYY-MM-DD):", 5, gbc);
        
        // Botón de registro
        JButton btnRegistrar = new JButton("✓ Registrar Alimento");
        btnRegistrar.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnRegistrar.setBackground(COLOR_PRIMARIO);
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setFocusPainted(false);
        btnRegistrar.setBorderPainted(false);
        btnRegistrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRegistrar.setPreferredSize(new Dimension(200, 45));
        
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 10, 10, 10);
        formulario.add(btnRegistrar, gbc);
        
        btnRegistrar.addActionListener(e -> {
            try {
                String donante = txtDonante.getText().trim();
                String tipo = (String) cmbTipo.getSelectedItem();
                String nombre = txtNombre.getText().trim();
                int cantidad = Integer.parseInt(txtCantidad.getText().trim());
                String fechaRec = txtFechaRecepcion.getText().trim();
                String fechaVen = txtFechaVencimiento.getText().trim();
                
                if (donante.isEmpty() || nombre.isEmpty() || fechaRec.isEmpty() || fechaVen.isEmpty()) {
                    mostrarMensaje("Por favor complete todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                Alimento alimento = new Alimento(nombre, tipo, cantidad, donante, fechaRec, fechaVen);
                admin.registrarAlimento(alimento);
                
                mostrarMensaje("¡Alimento registrado exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                
                // Limpiar formulario
                txtDonante.setText("");
                txtNombre.setText("");
                txtCantidad.setText("");
                txtFechaRecepcion.setText("");
                txtFechaVencimiento.setText("");
                cmbTipo.setSelectedIndex(0);
                
                actualizarVistas();
                
            } catch (NumberFormatException ex) {
                mostrarMensaje("La cantidad debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                mostrarMensaje("Error al registrar alimento: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        panel.add(formulario, BorderLayout.CENTER);
        
        return panel;
    }

    private JTextField agregarCampoFormulario(JPanel panel, String label, int fila, GridBagConstraints gbc) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbl.setForeground(COLOR_TEXTO);
        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.gridwidth = 1;
        panel.add(lbl, gbc);
        
        JTextField txt = new JTextField(20);
        txt.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            new EmptyBorder(8, 10, 8, 10)
        ));
        gbc.gridx = 1;
        panel.add(txt, gbc);
        
        return txt;
    }

    private void agregarCampoFormulario(JPanel panel, String label, JComponent componente, int fila, GridBagConstraints gbc) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbl.setForeground(COLOR_TEXTO);
        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.gridwidth = 1;
        panel.add(lbl, gbc);
        
        gbc.gridx = 1;
        panel.add(componente, gbc);
    }

    private JPanel crearPanelInventario() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));
        
        JLabel titulo = new JLabel("Inventario de Alimentos");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setForeground(COLOR_TEXTO);
        panel.add(titulo, BorderLayout.NORTH);
        
        // Tabla
        String[] columnas = {"Nombre", "Tipo", "Cantidad", "Donante", "F. Recepción", "F. Vencimiento"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable tabla = new JTable(modelo);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabla.setRowHeight(35);
        tabla.setSelectionBackground(new Color(200, 230, 201));
        tabla.setSelectionForeground(COLOR_TEXTO);
        tabla.setGridColor(new Color(240, 240, 240));
        tabla.setShowGrid(true);
        
        JTableHeader header = tabla.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(COLOR_PRIMARIO);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(0, 40));
        
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            tabla.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        JScrollPane scrollPane = new JScrollPane(tabla);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel crearPanelDistribucion() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));
        
        JLabel titulo = new JLabel("Distribución de Alimentos");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setForeground(COLOR_TEXTO);
        panel.add(titulo, BorderLayout.NORTH);
        
        JPanel contenido = new JPanel(new BorderLayout(15, 15));
        contenido.setBackground(COLOR_CARD);
        contenido.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
            new EmptyBorder(30, 30, 30, 30)
        ));
        
        JLabel info = new JLabel("<html><center>Haga clic en el botón para distribuir los alimentos<br>a los departamentos según prioridad</center></html>");
        info.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        info.setHorizontalAlignment(SwingConstants.CENTER);
        info.setForeground(COLOR_TEXTO_SECUNDARIO);
        contenido.add(info, BorderLayout.NORTH);
        
        JTextArea areaResultado = new JTextArea();
        areaResultado.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        areaResultado.setEditable(false);
        areaResultado.setBackground(new Color(250, 250, 250));
        areaResultado.setBorder(new EmptyBorder(15, 15, 15, 15));
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        
        JScrollPane scroll = new JScrollPane(areaResultado);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230), 1));
        contenido.add(scroll, BorderLayout.CENTER);
        
        JButton btnDistribuir = new JButton("🚚 Ejecutar Distribución");
        btnDistribuir.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnDistribuir.setBackground(COLOR_PRIMARIO);
        btnDistribuir.setForeground(Color.WHITE);
        btnDistribuir.setFocusPainted(false);
        btnDistribuir.setBorderPainted(false);
        btnDistribuir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnDistribuir.setPreferredSize(new Dimension(0, 50));
        
        btnDistribuir.addActionListener(e -> {
            PriorityQueue<Alimento> copiaCola = admin.getCola();
            
            if (copiaCola.isEmpty()) {
                areaResultado.setText("⚠️  No hay alimentos disponibles para distribuir.");
                return;
            }
            
            var resultado = distribuidor.distribuir(copiaCola);
            
            StringBuilder mensaje = new StringBuilder("✓ DISTRIBUCIÓN COMPLETADA\n");
            mensaje.append("═══════════════════════════════\n\n");
            
            int total = 0;
            for (String dep : resultado.keySet()) {
                int cantidad = resultado.get(dep);
                mensaje.append(String.format("• %-20s: %,d unidades\n", dep, cantidad));
                total += cantidad;
            }
            
            mensaje.append("\nn");
            mensaje.append(String.format("TOTAL DISTRIBUIDO: %,d unidades", total));
            
            areaResultado.setText(mensaje.toString());
        });
        
        contenido.add(btnDistribuir, BorderLayout.SOUTH);
        panel.add(contenido, BorderLayout.CENTER);
        
        return panel;
    }

    private void mostrarMensaje(String mensaje, String titulo, int tipo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, tipo);
    }

    private void actualizarVistas() {
        actualizarDashboard();
        actualizarInventario();
    }

    private void actualizarDashboard() {
        PriorityQueue<Alimento> cola = admin.getCola();
        
        // Actualizar estadísticas (buscar componentes en el panel dashboard)
        Component[] componentes = panelDecontrol.getComponents();
        for (Component c : componentes) {
            if (c instanceof JPanel) {
                JPanel p = (JPanel) c;
                if (p.getLayout() instanceof GridLayout && p.getComponentCount() == 4) {
                    // Panel de estadísticas
                    actualizarCardEstadistica((JPanel) p.getComponent(0), String.valueOf(cola.size()));
                    
                    int proximosAVencer = contarProximosAVencer(cola);
                    actualizarCardEstadistica((JPanel) p.getComponent(1), String.valueOf(proximosAVencer));
                    
                    int totalUnidades = calcularTotalUnidades(cola);
                    actualizarCardEstadistica((JPanel) p.getComponent(2), String.format("%,d", totalUnidades));
                }
            }
        }
    }

    private void actualizarCardEstadistica(JPanel card, String nuevoValor) {
        Component[] componentes = card.getComponents();
        for (Component c : componentes) {
            if (c instanceof JPanel) {
                JPanel panelTexto = (JPanel) c;
                Component[] labels = panelTexto.getComponents();
                for (Component l : labels) {
                    if (l instanceof JLabel) {
                        JLabel lbl = (JLabel) l;
                        if (lbl.getFont().getSize() == 28) {
                            lbl.setText(nuevoValor);
                            return;
                        }
                    }
                }
            }
        }
    }

    private void actualizarInventario() {
        // Encontrar la tabla en el panel de inventario
        Component[] componentes = panelInventario.getComponents();
        for (Component c : componentes) {
            if (c instanceof JScrollPane) {
                JScrollPane scroll = (JScrollPane) c;
                JTable tabla = (JTable) scroll.getViewport().getView();
                DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
                modelo.setRowCount(0);
                
                PriorityQueue<Alimento> cola = new PriorityQueue<>(admin.getCola());
                while (!cola.isEmpty()) {
                    Alimento a = cola.poll();
                    modelo.addRow(new Object[]{
                        a.getNombre(),
                        a.getTipo(),
                        a.getCantidad(),
                        a.getDonante(),
                        a.getFechaRecepcion(),
                        a.getFechaVencimiento()
                    });
                }
                break;
            }
        }
    }

    private int contarProximosAVencer(PriorityQueue<Alimento> cola) {
        // Simplificado: contar los primeros 5 en la cola de prioridad
        return Math.min(5, cola.size());
    }

    private int calcularTotalUnidades(PriorityQueue<Alimento> cola) {
        int total = 0;
        for (Alimento a : cola) {
            total += a.getCantidad();
        }
        return total;
    }

    private void cargarDatosPrueba() {
      
    }





    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
