/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.compensar.codigo;

import java.util.PriorityQueue;

//Clase encargada de registrar, almacenar y administrar alimentos.

public class Administrador {

   
    private PriorityQueue<Alimento> colaPrioridad = new PriorityQueue<>();

    
    public void registrarAlimento(Alimento alimento) {
        colaPrioridad.add(alimento);
    }

    
    public Alimento proximoAVencer() {
        return colaPrioridad.peek();
    }

   
    public PriorityQueue<Alimento> getCola() {
        return new PriorityQueue<>(colaPrioridad);
    }
}
