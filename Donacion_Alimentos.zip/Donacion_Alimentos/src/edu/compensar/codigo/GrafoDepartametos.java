/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.compensar.codigo;

/**
 *
 * @author simon
 */
public class GrafoDepartametos {

    private String[] departamentos = {
        "La Guajira", "Sucre", "Córdoba", "Chocó", "Vaupés", "Guainía",
        "San Andrés", "Nariño", "Atlántico", "Bolívar", "Vichada",
        "Casanare", "Cesar", "Magdalena"
    };

    private double[] porcentajes = {
        52.4, 49.5, 47.6, 36.3, 46.1, 37.5, 31.8,
        37.2, 40.0, 35.8, 42.5, 34.4, 30.3, 32.1
    };

    // Matriz de adyacencia del grafo
    private boolean[][] conexiones;

    public GrafoDepartametos() {
        int n = departamentos.length;
        conexiones = new boolean[n][n];

        // Conectamos de forma simple cada departamento con el siguiente
        for (int i = 0; i < n - 1; i++) {
            conexiones[i][i + 1] = true;
            conexiones[i + 1][i] = true;
        }
    }

    public String[] getDepartamentos() {
        return departamentos;
    }

    public double[] getPorcentajes() {
        return porcentajes;
    }

    public boolean[][] getConexiones() {
        return conexiones;
    }
}
